<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Kontakt</title>
</head>

<body>


<!-- bliver indsat der hvor man siger den skal inkluderes - derfor bliver den sat i starten af siden nu. Dette kan sammenlignes lidt med stylesheet - det er et ark man peger hen imod og henter informationer fra. Man henviser og henter derfor fra en anden fil. Dette kan evt. også gøres med en footer. -->


<?php 

include 'menu.php';

?>

<h1>Kontakt</h1>
<p>Dette er kontaktsiden</p>

