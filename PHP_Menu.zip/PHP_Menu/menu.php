<!--her linkes til stylesheet -->

<link rel="stylesheet" type="text/css" href="stylesheet.css">


<!-- curpage indeholder stien hen til filen. --> 

<?php 
$curpage = basename ($_SERVER['PHP_SELF']);
?>


<!-- For at markere hvilke sider der er aktive, skal der indsættes php. Her fortæller man, at hvis man er på den pågældende side skal den vise brugeren, at den er aktiv. Altså echo'er man denne "besked" ud.-->

    <ul id="nav">
        <li><a href="hjem.php" <?php if ($curpage == 'hjem.php') {echo 'class="active"';}?>>Hjem</a></li>
        <li><a href="projekter.php"<?php if ($curpage == 'projekter.php') {echo 'class="active"';}?>>Projekter</a></li>
        <li><a href="kontakt.php" <?php if ($curpage == 'kontakt.php') {echo 'class="active"';}?>>Kontakt</a></li>
    </ul>
